/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author hp
 */

import java.sql.*;                    // To invoked MySQL queries.

public class C{
    
public Connection c;                  // Established the connection with MySQL.
public Statement s;                   // Helps to execute MySQL queries.

public C(){                           // Constructor c
    try{
        Class.forName("com.mysql.jdbc.Driver");                                     // [.forName] method helps to Set the Driver.
        c=DriverManager.getConnection("jdbc:mysql:///java_project","root","");      //  Set Connection interface.
        s=c.createStatement();
    }catch(Exception e){
        e.printStackTrace();
    }
}
}
