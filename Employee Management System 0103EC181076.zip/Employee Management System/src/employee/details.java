package employee;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class details implements ActionListener{
    
    JFrame f;
    JLabel l1, l2;
    JButton b1,b2,b3,b4;
    
    details(){
        f=new JFrame("Employee Detail");
        f.setBackground(Color.WHITE);
        f.setLayout(null);
         
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/detail.jpg"));
        Image i2= i1.getImage().getScaledInstance(600, 400,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        l1 = new JLabel(i3);
        l1.setBounds(0,0,600,400);
        l1.setLayout(null);
       
        f.add(l1);
         
        l2 = new JLabel ("Employee Details");
        l2.setBounds(350, 30, 200, 40);
        l2.setFont(new Font("serif", Font.BOLD,25));
        l2.setForeground(Color.BLACK);
        l1.add(l2);
        
        b1=new JButton("Add");
        b1.setBounds(250,150,100,40);
        b1.setFont(new Font ("serif", Font.BOLD,15));
        b1.setForeground(Color.WHITE);
        b1.setBackground(Color.BLACK);
        b1.addActionListener(this);
        l1.add(b1);
        
        b2=new JButton("View");
        b2.setBounds(450,150,100,40);
        b2.setFont(new Font ("serif", Font.BOLD,15));
        b2.setForeground(Color.WHITE);
        b2.setBackground(Color.BLACK);
        b2.addActionListener(this);
        l1.add(b2);
        
        b3=new JButton("Remove");
        b3.setBounds(250,240,100,40);
        b3.setFont(new Font ("serif", Font.BOLD,15));
        b3.setForeground(Color.WHITE);
        b3.setBackground(Color.BLACK);
        b3.addActionListener(this);
        l1.add(b3);
        
        b4=new JButton("Update");
        b4.setBounds(450,240,100,40);
        b4.setBackground(Color.BLACK);
        b4.setForeground(Color.WHITE);
        b4.setFont(new Font ("serif", Font.BOLD,15));
        b4.addActionListener(this);
        l1.add(b4);
        
        f.setVisible(true);
        f.setSize(600,400);
        f.setLocation(450,100);
        
    }
    
    public void actionPerformed(ActionEvent ae){   // ActionEvent decide which event user select/clicked.
        if(ae.getSource()==b1){     //Open the AddEmployee frame & closing the current frame.
            f.setVisible(false);
            new AddEmployee();      // Object of AddEmployee class.
        }
        
        if(ae.getSource()==b2){     //Open the AddEmployee frame & closing the current frame.
            f.setVisible(false);
            new View_Employee();    // Object of View_Employee.
        }
        
        if(ae.getSource()==b3){     //Open the AddEmployee frame & closing the current frame.
            f.setVisible(false);
            new Remove_Employee();  // Object of Remove_Employee.
        }
        
        if(ae.getSource()==b4){      //Open the AddEmployee frame & closing the current frame.
            f.setVisible(false);
            new Search_Employee();   // Object of Search_Employee class.
        } 
 }
    public static void main(String[] arg){
        details d = new details();
    }
           
}
      
