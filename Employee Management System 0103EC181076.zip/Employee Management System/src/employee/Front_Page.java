package employee;
import java.awt.*;
import javax.swing.*;
import java.lang.Thread;
import java.awt.event.*;

class Front_Page implements ActionListener{
    JFrame f;
    JLabel id,l1;
    JButton b;
    
    Front_Page(){                                               // Constructor.
        
        f=new JFrame("Employee Management System");             // Object of JFrame
        f.setBackground(Color.WHITE);                            // To Set The Background Colour at topmost right 0f frame.
        f.setLayout(null);
        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/frontpage.jpg"));
        Image i2= i1.getImage().getScaledInstance(500, 500, Image.SCALE_DEFAULT); // To change the size(length,width) of image by the help of [getScaledInstance] method.
        ImageIcon i3=new ImageIcon(i2);  // We can't directly change the size of Icon so we do indirectly.
        JLabel l1= new JLabel(i3);
        l1.setBounds(40,30,600,500);     // distance of image from x-axis, y-axis of frame & length, width of image.
        f.add(l1);                       // Adding the image to JFrame.
        
        b=new JButton("CLICK HERE TO CONTINUE");
        b.setBackground(Color.BLACK);     // set the colour of biutton.
        b.setForeground(Color.WHITE);     // set the colour of characters written on the button.
        
        
        b.setBounds(200, 450, 200, 50);  // distance of button from x-axis, y-axis from frame & size(length, width) of button.
        b.addActionListener(this);       // To enable clicking function.
        
        /*id=new JLabel();
        id.setBounds(0, 0, 500, 750);   // we take the same length-1360 as that of Frame bez we have to put button on the frame.
        id.setLayout(null);*/
        
        JLabel lid= new JLabel("Employee Management System");
        lid.setBounds(0, 100, 600, 100);  // distance of label from x-axis, y-axis of frame & size of label.
        lid.setFont(new Font("serif", Font.PLAIN,48));  // size of font.
        lid.setForeground(Color.RED);                   // colour of Label.
        l1.add(lid);       // Adding label "Employee Management System" on the Image.
        
       // id.add(b);     //Adding button to label.
        l1.add(b);     // Adding button on image.
        
        
        f.getContentPane().setBackground(Color.YELLOW);  // set the frame background colour.
        
        f.setVisible(true);              // enable/visible the frame
        f.setSize(700,600);              // size of frame (length & width)
        f.setLocation(300, 100);         // distance of frame from x-axis & y-axis of the wimdow screen.
        
        while(true){                     // to enable the blinking. 
            lid.setVisible(false);
        try{ 
            Thread.sleep(500);           // [1000msec = 1sec] here time is 0.2sec.
        }catch(Exception e){}
        lid.setVisible(true);
        try{
            Thread.sleep(1000);
        }catch(Exception e){}
            }
        
        }
        public void actionPerformed(ActionEvent ae){  // Making the action event of action listener
            
            if(ae.getSource()==b){
                f.setVisible(false);  // current frame get hide & new frame get opened.
                login l= new login();  // calling the constructor of L.ogin class
               }
            }
        
        public static void main(String[] arg){
            Front_Page f=new Front_Page();
           }
        }
        
      